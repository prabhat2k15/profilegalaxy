<header class="header black-bg">
        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
              <div class="sidebar-toggle-box" style="margin-left: 20px;">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="U chaT"></div>
              </div>
            <!--logo start-->
            <a href="#" class="logo"><strong><b style="color: #FF0606;">U</b></strong>&nbsp;cha<b style="color: #005100;">T</b></a>
            <!--logo end-->
            <!-- Top Menu Items -->
            <div style="float: right; margin-right: 10px;">
            <ul class="nav navbar-right top-nav">
                <li class="dropdown" style="float: left;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge bg-theme">4</span><i class="fa fa-envelope"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu message-dropdown">
                        <li style="width: 150px; margin-left: 100px;">
                            <div><h3>You have 4 notification</h3></div>
                        </li>
                    </ul>
                </li>
                <li class="dropdown" style="float: left;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge bg-theme">4</span><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>

                <li class="dropdown" style="float: right;">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> John Smith <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-envelope"></i> Inbox</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>



        </nav>
        <!-- /end Navigation -->
</header>
