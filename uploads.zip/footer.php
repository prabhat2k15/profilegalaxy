<footer class="site-footer">
          <div class="text-center">
              2016 - &copy; Prab-Hat &nbsp;&nbsp;<img src="uploads/logo.png" height="40" width="40"></img>
              <a href="index.html#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>