<?php
	$cat=$_POST['cat'];
	echo $cat;
?>